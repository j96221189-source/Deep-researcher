"use client";

import { FormEvent, useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

type Result = { report: string; model: string; requestId?: string | null; error?: string };

const examples = [
  "Compare the leading open-source AI agent frameworks using official documentation and recent independent evaluations.",
  "What changed in the latest major AI regulation? Prioritize official government and primary sources.",
  "Evaluate the evidence for three approaches to reducing hallucinations in retrieval-augmented generation.",
];

export default function Home() {
  const [question, setQuestion] = useState("");
  const [result, setResult] = useState<Result | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError("");
    setResult(null);
    try {
      const response = await fetch("/api/research", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question }),
      });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error || "Research request failed.");
      setResult(payload);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Unexpected error. Please try again.");
    } finally {
      setBusy(false);
    }
  }

  function downloadReport() {
    if (!result?.report) return;
    const blob = new Blob([`# Deep Researcher report\n\nQuestion: ${question}\n\n${result.report}\n`], { type: "text/markdown;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = "deep-research-report.md";
    anchor.click();
    URL.revokeObjectURL(url);
  }

  return (
    <main className="shell">
      <header className="topbar">
        <a className="brand" href="/" aria-label="Deep Researcher home"><span className="brand-mark">D</span><span>Deep Researcher</span></a>
        <span className="status-pill"><span className="status-dot" /> OpenRouter · Web search</span>
      </header>

      <section className="hero">
        <div className="eyebrow"><span className="eyebrow-line" /> RESEARCH, WITH RECEIPTS</div>
        <h1>Go beyond the<br /><span>first answer.</span></h1>
        <p className="hero-copy">Investigate complex questions, compare credible sources, and turn what you find into a clear, cited report.</p>
      </section>

      <section className="workspace">
        <form className="research-card" onSubmit={submit}>
          <div className="card-heading">
            <div><div className="section-kicker">NEW INVESTIGATION</div><h2>What should we research?</h2></div>
            <span className="sparkle">✳</span>
          </div>
          <label className="sr-only" htmlFor="question">Research question</label>
          <textarea id="question" value={question} onChange={e => setQuestion(e.target.value)} minLength={10} maxLength={10000} required rows={5} placeholder="Ask a question that deserves more than a quick search…" />
          <div className="input-footer"><span>{question.length.toLocaleString()} / 10,000 characters</span><span>Primary sources · Citations · Uncertainty</span></div>
          <div className="examples">
            <span className="examples-label">TRY A STARTER</span>
            {examples.map((example, i) => <button key={example} type="button" className="example-chip" onClick={() => setQuestion(example)}>{["Framework comparison", "Policy research", "Evidence review"][i]} <span>↗</span></button>)}
          </div>
          <div className="form-bottom">
            <div className="privacy-note"><span className="lock-icon">⌑</span><span>Your question is sent to the configured AI provider.</span></div>
            <button className="submit-button" type="submit" disabled={busy || question.trim().length < 10}>
              {busy ? <><span className="spinner" /> Researching…</> : <>Start research <span>↗</span></>}
            </button>
          </div>
        </form>

        {busy && <section className="progress-card" aria-live="polite"><div className="progress-orbit"><span /></div><div><h3>Research in progress</h3><p>Searching the web and synthesizing available evidence. Keep this tab open for this first prototype.</p></div></section>}
        {error && <section className="error-card" role="alert"><strong>We couldn't complete the research.</strong><p>{error}</p><span>Check the server configuration and try again.</span></section>}

        {result && <section className="report-card" aria-live="polite">
          <div className="report-head"><div><div className="section-kicker">INVESTIGATION COMPLETE</div><h2>Your research report</h2><p>Model: {result.model}</p></div><button className="download-button" onClick={downloadReport} type="button">↓ Download Markdown</button></div>
          <article className="markdown-body"><ReactMarkdown remarkPlugins={[remarkGfm]}>{result.report}</ReactMarkdown></article>
          <div className="report-foot"><span>Review source links and verify consequential claims before relying on this report.</span>{result.requestId && <span>Request {result.requestId.slice(0, 12)}</span>}</div>
        </section>}
      </section>
      <footer className="footer"><span>DEEP RESEARCHER <span className="footer-sep">/</span> EARLY ACCESS</span><span>Evidence first. Confidence earned.</span></footer>
    </main>
  );
}
