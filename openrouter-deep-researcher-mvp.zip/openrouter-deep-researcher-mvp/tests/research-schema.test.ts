import { describe, expect, it } from "vitest";
import { researchQuestionSchema } from "../lib/research-schema";

describe("researchQuestionSchema", () => {
  it("accepts a useful research question", () => {
    expect(researchQuestionSchema.safeParse({
      question: "Compare current open-source research agents.",
    }).success).toBe(true);
  });

  it("rejects too-short questions", () => {
    expect(researchQuestionSchema.safeParse({ question: "hi" }).success).toBe(false);
  });

  it("rejects oversized questions", () => {
    expect(researchQuestionSchema.safeParse({ question: "x".repeat(10_001) }).success).toBe(false);
  });

  it("trims whitespace", () => {
    const result = researchQuestionSchema.parse({ question: "  Compare three research agents  " });
    expect(result.question).toBe("Compare three research agents");
  });
});
