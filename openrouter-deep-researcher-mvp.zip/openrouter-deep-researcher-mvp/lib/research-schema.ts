import { z } from "zod";

export const researchQuestionSchema = z.object({
  question: z.string().trim().min(10).max(10_000),
});

export type ResearchQuestion = z.infer<typeof researchQuestionSchema>;
