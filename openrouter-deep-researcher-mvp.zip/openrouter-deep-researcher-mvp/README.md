# OpenRouter Deep Researcher — first working milestone

A Next.js + TypeScript research UI that calls OpenRouter's Chat Completions API with its built-in `openrouter:web_search` server tool. It includes server-side model fallback, Markdown report rendering, and client-side Markdown download.

## What works in this milestone

- Research question form and example prompts
- Server-only OpenRouter credentials
- Configurable primary and fallback model IDs
- Bounded web-search tool calls
- Input validation, provider error handling, timeout
- Markdown report rendering and download
- Unit tests for request validation

## Important limitations

This is a first working vertical slice, **not yet the full production architecture**. It performs research in one request, so it does not yet provide durable background jobs, persistent job history, authentication, per-user quotas, private object storage, cancellation, or a durable queue. Do not expose it to untrusted public traffic until those protections are implemented. Vercel function execution is bounded; move long-running work to a durable worker/queue before supporting long reports at scale.

OpenRouter's web search server tool is documented as beta and may change. See https://openrouter.ai/docs/guides/features/server-tools/web-search.

## Deploy to Vercel

1. Create a new GitHub repository and upload/push the files in this folder.
2. In Vercel, choose **Add New → Project** and import that repository.
3. Keep the detected Next.js framework and default build settings.
4. In **Project Settings → Environment Variables**, add:
   - `OPENROUTER_API_KEY` — your OpenRouter API key
   - `RESEARCH_MODEL` — a currently supported model ID with tool-calling support
   - `RESEARCH_FALLBACK_MODEL` — a tested lower-cost model ID that also supports the web-search tool
   - `RESEARCH_MAX_TOOL_CALLS` — optional, e.g. `5`
   - `APP_BASE_URL` — optional, your deployed app URL
5. Redeploy after adding variables.
6. Test with a small, non-sensitive question.

Do not put the OpenRouter key in a `NEXT_PUBLIC_` variable or commit it to Git.

## Local development

```bash
cp .env.example .env.local
# Fill the required variables in .env.local
npm install
npm run dev
```

## Checks

```bash
npm run typecheck
npm test
npm run lint
npm run build
```

## Fallback policy

The route tries the fallback model only on rate limiting, server errors, or network/timeouts. Authentication and invalid-request failures are returned rather than hidden. Test both configured models against the same evaluation questions before production use.
